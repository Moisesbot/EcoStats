package com.moixbro.ecostats;

import org.bukkit.plugin.java.JavaPlugin;

public class EcoStats extends JavaPlugin {
    @Override
    public void onEnable() {
        getCommand("stats").setExecutor(new StatsCommand(this));
        saveDefaultConfig();
        getLogger().info("EcoStats PRO habilitado.");
    }
}