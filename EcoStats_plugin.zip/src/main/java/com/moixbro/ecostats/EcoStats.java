package com.moixbro.ecostats;

import org.bukkit.plugin.java.JavaPlugin;
import com.moixbro.ecostats.Commands.StatsCommand;
import com.moixbro.ecostats.Commands.StatsUpCommand;

public class EcoStats extends JavaPlugin {
    private static EcoStats instance;
    public void onEnable() {
        instance = this;
        getCommand("stats").setExecutor(new StatsCommand());
        getCommand("statsup").setExecutor(new StatsUpCommand());
        getLogger().info("EcoStats PRO enabled!");
    }

    public static EcoStats getInstance() {
        return instance;
    }
}
