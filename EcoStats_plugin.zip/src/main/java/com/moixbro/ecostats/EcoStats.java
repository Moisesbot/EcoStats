package com.moixbro.ecostats;

import org.bukkit.plugin.java.JavaPlugin;

public class EcoStats extends JavaPlugin {
    @Override
    public void onEnable() {
        getLogger().info("EcoStats habilitado.");
    }

    @Override
    public void onDisable() {
        getLogger().info("EcoStats deshabilitado.");
    }
}
