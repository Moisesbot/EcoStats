package com.moixbro.ecostats;

import java.io.File;
import java.util.HashMap;
import java.util.UUID;

public class StatsManager {
    private HashMap<UUID, Integer> strength = new HashMap<>();
    // Similar maps for speed, resistance, life

    public void loadStats(UUID uuid) {
        // Load stats from file
    }

    public void saveStats(UUID uuid) {
        // Save stats to file
    }
}
