package com.moixbro.ecostats.Commands;

import com.moixbro.ecostats.StatsManager;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class StatsCommand implements CommandExecutor {
    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player)) {
            sender.sendMessage("Only players can use this command.");
            return true;
        }

        Player player = (Player) sender;
        StatsManager manager = StatsManager.getInstance();
        manager.loadStats(player.getUniqueId());

        int strength = manager.getStat(player.getUniqueId(), "fuerza");
        int speed = manager.getStat(player.getUniqueId(), "velocidad");
        int resistance = manager.getStat(player.getUniqueId(), "resistencia");
        int life = manager.getStat(player.getUniqueId(), "vida");

        player.sendMessage(ChatColor.GREEN + "===== Tus Estadísticas =====");
        player.sendMessage(ChatColor.YELLOW + "Fuerza: " + ChatColor.WHITE + strength);
        player.sendMessage(ChatColor.YELLOW + "Velocidad: " + ChatColor.WHITE + speed);
        player.sendMessage(ChatColor.YELLOW + "Resistencia: " + ChatColor.WHITE + resistance);
        player.sendMessage(ChatColor.YELLOW + "Vida Extra: " + ChatColor.WHITE + life);
        player.sendMessage(ChatColor.GREEN + "============================");

        return true;
    }
}
