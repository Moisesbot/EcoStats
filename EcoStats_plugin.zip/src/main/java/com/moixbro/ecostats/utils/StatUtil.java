package com.moixbro.ecostats.utils;

import org.bukkit.attribute.Attribute;
import org.bukkit.entity.Player;

public class StatUtil {
    public static int calculateUpgradeCost(int currentLevel) {
        return 150000 + (currentLevel * 50000);
    }

    public static void applyStats(Player player, int fuerza, int velocidad, int resistencia, int vida) {
        // Vida extra
        double baseHealth = 20.0;
        double extraHearts = vida * 2.0; // 1 vida = 1 corazón (2 HP)
        player.getAttribute(Attribute.GENERIC_MAX_HEALTH).setBaseValue(baseHealth + extraHearts);

        // Velocidad
        double baseSpeed = 0.2;
        double speedBonus = velocidad * 0.02;
        player.getAttribute(Attribute.GENERIC_MOVEMENT_SPEED).setBaseValue(baseSpeed + speedBonus);

        // Fuerza y resistencia se aplicarán en combate (deben integrarse con eventos)
    }
}
