package com.moixbro.ecostats;

import org.bukkit.plugin.java.JavaPlugin;

public class EcoStats extends JavaPlugin {
    @Override
    public void onEnable() {
        getLogger().info("EcoStats PRO habilitado!");
        saveDefaultConfig();
        getCommand("stats").setExecutor(new StatsCommand(this));
        getServer().getPluginManager().registerEvents(new StatsListener(this), this);
    }
}
