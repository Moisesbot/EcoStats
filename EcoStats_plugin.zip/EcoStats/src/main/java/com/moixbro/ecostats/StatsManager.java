package com.moixbro.ecostats;

public class StatsManager {
    // Aquí irían funciones para guardar y cargar estadísticas complejas
}
