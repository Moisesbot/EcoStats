package com.moixbro.ecostats;

import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.EventHandler;
import org.bukkit.entity.Player;

public class StatsListener implements Listener {
    private EcoStats plugin;

    public StatsListener(EcoStats plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent event) {
        Player player = event.getPlayer();
        plugin.getConfig().addDefault(player.getName() + ".money-earned", 0);
        plugin.saveConfig();
    }
}
