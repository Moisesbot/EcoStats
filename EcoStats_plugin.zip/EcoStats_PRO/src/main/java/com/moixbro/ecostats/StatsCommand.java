package com.moixbro.ecostats;

import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import net.milkbowl.vault.economy.Economy;
import org.bukkit.Bukkit;
import org.bukkit.attribute.Attribute;

public class StatsCommand implements CommandExecutor {
    private final EcoStats plugin;
    private final Economy economy;

    public StatsCommand(EcoStats plugin) {
        this.plugin = plugin;
        this.economy = Bukkit.getServer().getServicesManager().getRegistration(Economy.class).getProvider();
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player)) return true;
        Player player = (Player) sender;
        if (args.length < 2 || !args[0].equalsIgnoreCase("up")) return false;

        String stat = args[1].toLowerCase();
        int currentLevel = plugin.getConfig().getInt("players." + player.getUniqueId() + "." + stat, 0);
        double cost = 150000 + (currentLevel * 50000);

        if (!economy.has(player, cost)) {
            player.sendMessage("§cNo tienes suficiente dinero. Necesitas $" + cost);
            return true;
        }

        economy.withdrawPlayer(player, cost);
        plugin.getConfig().set("players." + player.getUniqueId() + "." + stat, currentLevel + 1);
        plugin.saveConfig();

        switch (stat) {
            case "fuerza":
                player.sendMessage("§aHas mejorado tu fuerza. Ahora haces más daño.");
                break;
            case "resistencia":
                double newHealth = 20 + ((currentLevel + 1) * 2);
                player.getAttribute(Attribute.GENERIC_MAX_HEALTH).setBaseValue(newHealth);
                player.sendMessage("§aHas mejorado tu resistencia. Vida máxima aumentada.");
                break;
            case "velocidad":
                player.setWalkSpeed(0.2f + (currentLevel + 1) * 0.01f);
                player.sendMessage("§aHas mejorado tu velocidad.");
                break;
            default:
                player.sendMessage("§cStat desconocida.");
        }
        return true;
    }
}